# Documento com Prints 

## Repositório Microsserviço

![Print 1](.\prints\microsservico.jpeg)

## Repositório Functions
![Print 2](.\prints\functions.jpeg)

## Repositório BFF
![Print 3](.\prints\bff.jpeg)

## Evidência requisição POST de compra (Service Bus)
![Print 4](.\prints\postservicebus.jpeg)

## Evidência Service Bus
![Print 5](.\prints\servicebus.jpeg)

## Evidência POST via API Gateway
![Print 6](.\prints\requisicaopost.jpeg)

## Evidência persistência no banco
![Print 7](.\prints\persistenciabd.jpeg)
